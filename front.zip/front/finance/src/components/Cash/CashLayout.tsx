
import image from '../../assets/Cash.png';
import { CardCash } from "./Card";
import { useCashData } from "../../hooks/ServiceAPI";
import "./CashLayout.scss"
import { useEffect, useState } from 'react';
import { Modal } from './Modal';

export function Cash(){
    const [isModalOpen, setModalOpen] = useState(false);

    const openModal = () => setModalOpen(true);
    const closeModal = () => setModalOpen(false);

    const {data: dataCash} = useCashData();

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
          const modal = document.getElementById('myModal');
          if (modal && event.target === modal) {
            closeModal();
          }
        };
        window.addEventListener('click', handleClickOutside);
        return () => window.removeEventListener('click', handleClickOutside);
      }, []);

    return(
        <div className="container-cash">
            <div className="cash">
                <div className="txt-cash">
                    <h4>Cash inflow </h4>
                </div>
                <div className="card-cash">
                    <div className="scroll-content">
                    {dataCash ? ( dataCash?.map(cash => 
                        <CardCash key={cash.id}
                        additionDate={cash.additionDate}
                        idCategory={cash.idCategory}
                        isEnabled={cash.isEnabled}
                        updateDate={cash.updateDate}
                        value={cash.value}
                        description={cash.description}
                        idAccount={''} id={''}/>
                    )
                    ) : (
                    <div>Loading cards...</div>
                    )} 
                    </div>
                </div>
            </div>
            <div className="cash-side">
                <img src={image} alt="Descrição da Imagem" />
                <div className="add-button" onClick={openModal}>+</div>
                
            </div>
            {isModalOpen && ( <Modal isOpen={isModalOpen} onClose={closeModal} /> )}
      </div>
      
    )
}