import './Modal.scss'; 

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Modal({isOpen, onClose}: ModalProps){
    if (!isOpen) return null;
    return(
        <div id="myModal" className="modal">
        <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <span className="close" onClick={onClose} >&times;</span>
            <p>Conteúdo do Modal...</p>
        </div>
        </div>
    )
}