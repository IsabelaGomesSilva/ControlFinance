import "./Card.scss"
import { CashData } from "../../interface/CashData";

const formatDate = (date: string | Date) => {
    if (!date) return "N/A"; // Retorna "N/A" se a data não estiver disponível
    const dateObj = typeof date === "string" ? new Date(date) : date;
    return dateObj.toLocaleDateString();
  };
export function CardCash(
    {   additionDate,
        idCategory,
        isEnabled,
        updateDate,
        value,
        description
    } : CashData
){
    return(
        <div className="card-cashs">
         
        <p><strong>Category ID:</strong> {idCategory}</p>
        <p><strong>Value:</strong> {value}</p>
        <p><strong>Description:</strong> {description}</p>
        <p><strong>Addition Date:</strong> {formatDate(additionDate)}</p>
        <p><strong>Update Date:</strong> {formatDate(updateDate)}</p>
        <p><strong>Is Enabled:</strong> {isEnabled ? 'Yes' : 'No'}</p>
        </div>
    )
}