export interface ExpensesData{
    additionDate: Date;
    idCategory: string;
    idAccount: string;
    description: string;
    id: string;
    isEnabled: boolean;
    updateDate: Date;
    value: number;
}