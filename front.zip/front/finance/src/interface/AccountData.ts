export interface AccountData {
    id:string;
    isEnabled: boolean;
    cashBalance: string;
    totalExpenses: string;
    totalCash: string;
}